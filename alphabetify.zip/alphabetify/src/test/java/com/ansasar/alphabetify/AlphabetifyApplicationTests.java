package com.ansasar.alphabetify;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlphabetifyApplicationTests {

	@Test
	void contextLoads() {
	}

}
