package com.ansasar.alphabetify;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AlphabetifyApplication {

	public static void main(String[] args) {
		SpringApplication.run(AlphabetifyApplication.class, args);
	}

}
